/***********file:   compare.h *********/
typedef enum {LESSER , GREATER , EQUAL} ORDER;
extern ORDER compare (Job j1,Job j2);
