#include"linkedlist.h"
#include<stdbool.h>

bool testCyclic(struct linkedList* head);
