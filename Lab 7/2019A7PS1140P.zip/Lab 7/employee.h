#include <stdio.h>
#include <stdlib.h>

typedef struct {
    char name[11];
    int empID;
}Employee;