#include "Credit_Card.h"

Credit_Card* read_record(char* file, int* size);
