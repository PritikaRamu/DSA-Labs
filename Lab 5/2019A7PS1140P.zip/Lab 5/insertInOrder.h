#include "Read_Records.h"

int* stack_top;

void insertInOrder(Credit_Card* cards, int size, Credit_Card newcard);
void insertionSort(Credit_Card* cards,int size);
